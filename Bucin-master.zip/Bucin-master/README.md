## Script Bucin

```
Rela NgeBucin Demi dapetin kamu 🥴
```
### Deploy dengan Github Pages
1. Fork Repo ini
2. Ke Menu Setting » Pages
3. Setting Seperti Gambar dibawah
<p align="center">
   <img src="https://i.ibb.co/bW4Fh4c/Screenshot-113.png" alt="Github Pages">
</p>
4. DEMO Yang sudah di Deploy di Github Pages: https://mrismanaziz.github.io/Bucin/

### Deploy dengan Vercel
1. Daftar Akun Vercel Disini https://vercel.com/signup
2. Klik Link ini https://vercel.com/new/git/third-party
<p align="left">
   <img src="https://i.ibb.co/XX19Ryp/Screenshot-114.png" alt="Vercel app">
</p>
3. DEMO Yang sudah di Deploy di Vercel : https://iloveu.now.sh
